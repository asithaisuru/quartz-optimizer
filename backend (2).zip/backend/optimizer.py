import trimesh
import numpy as np
import os
import copy
import concurrent.futures
from gem_shapes import get_standard_shapes

# --- CONFIG ---
SAFETY_FACTOR = 0.95
MIN_WALL_DIST = -0.005 
MIN_VOLUME_RATIO = 0.02
GEM_SPACING_BUFFER = 0.05 
MAX_GEMS = 5

def check_overlap(new_gem, existing_gems):
    """
    Checks collision between new gem and existing gems list.
    Uses Fast AABB check first, then strict vertex check.
    """
    if not existing_gems: return False
    
    # 1. Expand new gem for safety spacing (Kerf)
    cutter = new_gem.copy()
    cutter.apply_scale(1.0 + GEM_SPACING_BUFFER)
    min_n, max_n = cutter.bounds
    
    for ex in existing_gems:
        min_e, max_e = ex.bounds
        
        # Fast AABB Check (If boxes don't touch, meshes don't touch)
        if np.any(min_n > max_e) or np.any(max_n < min_e): 
            continue
        
        # Slow Vertex Check (Mesh vs Mesh vertices)
        if np.any(ex.contains(cutter.vertices)): return True
        if np.any(cutter.contains(ex.vertices)): return True
            
    return False

def get_max_scale_binary(rough_prox, gem, position, min_dim, max_dim, obstacles):
    """
    Finds exact max scale using Binary Search + Proximity + Overlap Check.

    FIX: gem passed in is centered at origin (unit size).
    We scale it at origin first, THEN translate to position.
    This avoids the double-position bug where scaling was applied
    to already-translated vertices causing the gem to grow outward.
    """
    # gem.vertices are centered at origin (guaranteed by caller)
    base_verts = gem.vertices.copy()  # Shape at origin, unit scale

    low = 0.0
    high = max_dim
    best_scale = 0.0
    
    # Binary Search (12 steps)
    for _ in range(12):
        mid = (low + high) / 2.0
        
        # CORRECT ORDER: Scale at origin, then translate to position
        current_verts = base_verts * mid + position
        
        # Build temporary mesh for overlap check
        test_gem = gem.copy()
        test_gem.vertices = current_verts
        
        # 1. OBSTACLE CHECK (Must NOT collide)
        if check_overlap(test_gem, obstacles):
            high = mid  # Hit a neighbor, too big
            continue

        try:
            # 2. WALL CHECK (Must be INSIDE rough stone)
            # signed_distance < 0 means inside, > 0 means outside
            sdf = rough_prox.signed_distance(current_verts)
            worst_point = np.max(sdf)
            
            if worst_point < MIN_WALL_DIST:
                best_scale = mid
                low = mid  # Fits! Try bigger.
            else:
                high = mid  # Hit wall.
        except:
            high = mid
            
    return best_scale

# --- WORKER ---
def worker_check_rot(args):
    (rot, search_points, rough_V, rough_F, obstacles_V_list, obstacles_F_list, gem_V, gem_F, min_dim, max_dim) = args
    
    # Rebuild Rough & Prox
    rough = trimesh.Trimesh(vertices=rough_V, faces=rough_F)
    try:
        prox = trimesh.proximity.ProximityQuery(rough)
    except:
        return 0.0, None, rot  # Fail safe

    # Rebuild Obstacles
    obstacles = []
    if obstacles_V_list:
        for v, f in zip(obstacles_V_list, obstacles_F_list):
            obstacles.append(trimesh.Trimesh(vertices=v, faces=f))

    # Apply rotation to gem (still centered at origin)
    base_gem = trimesh.Trimesh(vertices=gem_V, faces=gem_F)
    base_gem.apply_transform(rot)

    # Re-center after rotation (rotation can shift centroid slightly)
    base_gem.vertices -= base_gem.bounds.mean(axis=0)
    
    best_scale = 0.0
    best_pos = None
    
    for pos in search_points:
        # gem is at origin, position is passed separately — no pre-translation
        scale = get_max_scale_binary(prox, base_gem, pos, min_dim, max_dim, obstacles)
        
        if scale > best_scale:
            best_scale = scale
            best_pos = pos
            
    return best_scale, best_pos, rot

def find_best_gem_in_space(rough, shapes, obstacles, search_points, min_dim, max_dim, progress_callback=None):
    # Prepare data for threads (Raw Arrays are picklable)
    rough_V = rough.vertices
    rough_F = rough.faces
    
    obs_V_list = [m.vertices for m in obstacles]
    obs_F_list = [m.faces for m in obstacles]
    
    # Rotations
    rotations = [np.eye(4)]
    for axis in [[1,0,0],[0,1,0],[0,0,1]]:
        rotations.append(trimesh.transformations.rotation_matrix(np.pi/2, axis))

    tasks = []
    task_info = []

    for name, tmpl in shapes.items():
        tmpl_copy = tmpl.copy()
        # Guarantee gem is centered at origin before passing to worker
        tmpl_copy.vertices -= tmpl_copy.bounds.mean(axis=0)
        
        gem_V = tmpl_copy.vertices
        gem_F = tmpl_copy.faces

        for rot in rotations:
            tasks.append((rot, search_points, rough_V, rough_F, obs_V_list, obs_F_list, gem_V, gem_F, min_dim, max_dim))
            task_info.append({"name": name, "gem_template": tmpl_copy})

    total_tasks = len(tasks)
    global_best = {"vol": 0, "gem": None, "name": ""}

    # Run Parallel
    max_cores = os.cpu_count() or 4
    with concurrent.futures.ProcessPoolExecutor(max_workers=max_cores) as executor:
        results = executor.map(worker_check_rot, tasks)
        
        for i, result in enumerate(results):
            if progress_callback and obstacles == [] and i % 10 == 0:
                progress_callback(i, total_tasks, "Scanning...")

            scale, pos, rot = result
            if scale > 0:
                info = task_info[i]
                
                # Apply Visual Safety Buffer
                final_scale = scale * SAFETY_FACTOR
                
                # Calculate Volume
                vol = (final_scale**3) * info['gem_template'].volume
                
                if vol > global_best["vol"]:
                    global_best["vol"] = vol
                    global_best["name"] = info['name']
                    
                    # FIX: Scale at origin FIRST, then translate to position.
                    # Old code did translate first then apply_scale() which scales
                    # from the mesh centroid (now at `pos`), causing the gem to
                    # grow outward and appear larger than the rough stone.
                    win = info['gem_template'].copy()
                    win.apply_transform(rot)
                    # Re-center after rotation
                    win.vertices -= win.bounds.mean(axis=0)
                    # Scale at origin
                    win.apply_scale(final_scale)
                    # Now translate to best position
                    win.vertices += pos
                    global_best["gem"] = win

    return global_best["gem"], global_best["vol"], global_best["name"]


def optimize_cut(rough_mesh_path, mode="multi", progress_callback=None):
    print(f"--- Running Geometric Optimization (Fixed Multi-Gem) ---")
    
    try:
        rough = trimesh.load(rough_mesh_path)
    except:
        return []

    # Center rough stone to origin
    rough.vertices -= rough.bounds.mean(axis=0)

    extents = rough.extents
    min_dim = np.min(extents)
    max_dim = np.max(extents)
    
    offset = np.max(extents) * 0.15
    center = np.array([0.0, 0.0, 0.0])
    
    search_points = [
        center,
        center + [offset, 0, 0], center - [offset, 0, 0],
        center + [0, offset, 0], center - [0, offset, 0],
        center + [0, 0, offset], center - [0, 0, offset]
    ]

    shapes = get_standard_shapes()
    
    # --- STEP 1: MAIN GEM ---
    print("   🔍 Finding Gem 1...")
    gem1, vol1, name1 = find_best_gem_in_space(rough, shapes, [], search_points, min_dim, max_dim, progress_callback)
    
    # Fallback Logic
    if not gem1:
        print("   ⚠️ Optimization failed. Creating Safety Fallback.")
        fallback_key = list(shapes.keys())[0]
        start_gem_template = shapes[fallback_key].copy()
        
        safe_scale = min_dim * 0.2
        gem1 = start_gem_template.copy()
        # Scale at origin first
        gem1.apply_scale(safe_scale)
        gem1.vertices -= gem1.bounds.mean(axis=0)
        
        vol1 = gem1.volume
        name1 = f"{fallback_key} (Fallback)"

    strategies = []
    strategies.append({
        "strategy": "Single Large",
        "shape": name1,
        "gems": [gem1],
        "total_volume": vol1
    })

    # --- STEP 2: MULTI-GEM ---
    if mode == "multi":
        if progress_callback: progress_callback(100, 100, "Fitting Secondary Gems...")
        
        current_gems = [gem1]
        current_vol = vol1
        current_names = [name1]
        
        # Try to fit more gems (Up to MAX_GEMS)
        for i in range(MAX_GEMS - 1):
            # Pass existing gems as obstacles
            g_next, v_next, n_next = find_best_gem_in_space(rough, shapes, current_gems, search_points, min_dim, max_dim)
            
            if g_next and v_next > (rough.volume * MIN_VOLUME_RATIO):
                print(f"      + Added Gem {i+2}: {n_next} (Vol: {v_next:.3f})")
                current_gems.append(g_next)
                current_names.append(n_next)
                current_vol += v_next
            else:
                break
        
        if len(current_gems) > 1:
            strategies.append({
                "strategy": "Multi-Gem",
                "shape": f"{len(current_gems)} Gems Mixed",
                "gems": current_gems,
                "total_volume": current_vol
            })

    strategies.sort(key=lambda x: x['total_volume'], reverse=True)
    
    # Export Winner
    winner = strategies[0]
    output_dir = os.path.dirname(rough_mesh_path)
    combined = trimesh.util.concatenate(winner['gems'])
    combined.visual.face_colors = [255, 0, 0, 255]
    combined.export(os.path.join(output_dir, "best_cut.ply"))
    
    return strategies