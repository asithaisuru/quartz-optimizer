import trimesh
import numpy as np
import json
import os
from optimizer import optimize_cut
from ray_tracer import calculate_light_performance

DENSITY_QUARTZ = 2.65
CARATS_PER_GRAM = 5.0

def calculate_gem_stats(mesh_path, known_carats=None, progress_callback=None):
    if not os.path.exists(mesh_path): return {"error": "Mesh not found"}

    try:
        # Load & Center
        mesh = trimesh.load(mesh_path)
        center = mesh.bounds.mean(axis=0)
        mesh.apply_translation(-center)
        
        # Save Visual Stone
        aligned_path = mesh_path.replace("final_textured_model.ply", "visual_aligned_stone.ply")
        mesh.export(aligned_path)

        if not mesh.is_watertight: vol_mesh = mesh.convex_hull
        else: vol_mesh = mesh

        # Scale
        vol_original = vol_mesh.volume
        scale_factor = 1.0
        target_weight = 0.0
        
        if known_carats and float(known_carats) > 0:
            target_weight = float(known_carats)
            target_grams = target_weight / CARATS_PER_GRAM
            target_vol = target_grams / DENSITY_QUARTZ
            scale_factor = (target_vol / vol_original) ** (1/3)
        else:
            scale_factor = 2.0 / np.max(vol_mesh.extents)
            target_vol = vol_original * (scale_factor ** 3)
            target_weight = target_vol * DENSITY_QUARTZ * CARATS_PER_GRAM

        # Optimize
        optimizer_mesh = mesh.copy()
        optimizer_mesh.apply_scale(scale_factor) # Use Scaled mesh for logic?
        # NO: Use Unscaled for visual match, scale results later.
        # BUT: For multi-gem packing relative sizes, unscaled is fine.
        
        temp_opt_path = mesh_path.replace(".ply", "_opt_input.ply")
        mesh.export(temp_opt_path) # Export unscaled
        
        strategies = optimize_cut(temp_opt_path, mode="multi", progress_callback=progress_callback)
        
        options_data = []
        for i, strat in enumerate(strategies):
            # Calculate metrics
            plan_vol = strat['total_volume']
            yield_ratio = plan_vol / vol_original if vol_original > 0 else 0
            plan_weight = target_weight * yield_ratio
            yield_pct = yield_ratio * 100
            
            # Save Option File
            opt_filename = f"option_{i}.ply"
            opt_path = os.path.join(os.path.dirname(mesh_path), opt_filename)
            combined = trimesh.util.concatenate(strat['gems'])
            combined.visual.face_colors = [255, 0, 0, 255]
            combined.export(opt_path)

            # Ray Trace
            light = calculate_light_performance(opt_path)
            
            options_data.append({
                "name": strat['shape'],
                "type": strat['strategy'],
                "weight": round(plan_weight, 2),
                "yield": round(yield_pct, 1),
                "file": opt_filename,
                "light_score": light['score'],
                "light_grade": light['grade']
            })

        best = options_data[0]
        scaled_extents = vol_mesh.extents * scale_factor * 10 

        stats = {
            "volume_cm3": round(target_weight / CARATS_PER_GRAM / DENSITY_QUARTZ, 2),
            "dimensions_mm": [round(x, 2) for x in scaled_extents],
            "raw_carats": round(target_weight, 2),
            "estimated_cut_carats": best['weight'],
            "yield_percent": best['yield'],
            "recommended_shape": best['name'],
            "options": options_data,
            "light_analysis": {"score": best['light_score'], "grade": best['light_grade']}
        }
        return stats

    except Exception as e:
        print(f"❌ Error: {e}")
        return {"error": str(e)}