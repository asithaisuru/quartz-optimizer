import trimesh
import numpy as np
import os
import copy
import concurrent.futures
from gem_shapes import get_standard_shapes

# SAFETY: 95% of max size (Visual Gap)
SAFETY_FACTOR = 0.95
# Must be this deep inside (negative value)
MIN_WALL_DIST = -0.005
MIN_VOLUME_RATIO = 0.02
GEM_SPACING_BUFFER = 0.02

def get_max_scale_binary_prox(rough, gem, position, min_dim, max_dim, obstacle_bounds):
    """
    Finds exact max scale using Proximity (Distance Field).
    This prevents 'Swallowing' because outside points have positive distance.
    """
    # Create Proximity Engine LOCALLY (Thread-safe)
    prox = trimesh.proximity.ProximityQuery(rough)
    
    # Move gem to start
    base_gem = gem.copy()
    base_gem.vertices += position

    low = 0.0
    high = max_dim
    best_scale = 0.0
    
    # Binary Search
    for _ in range(12):
        mid = (low + high) / 2.0
        
        # Scale relative to center
        current_verts = (base_gem.vertices - position) * mid + position
        
        # 1. Bounding Box Check (Obstacles)
        min_v = np.min(current_verts, axis=0)
        max_v = np.max(current_verts, axis=0)
        
        collides = False
        if obstacle_bounds:
            for obs_min, obs_max in obstacle_bounds:
                if not (np.any(min_v > obs_max) or np.any(max_v < obs_min)):
                    collides = True; break
        if collides:
            high = mid; continue

        # 2. PROXIMITY CHECK
        try:
            # signed_distance: Negative = Inside, Positive = Outside
            sdf = prox.signed_distance(current_verts)
            worst_point = np.max(sdf)
            
            # STRICT RULE: Worst point must be deeper than MIN_WALL_DIST
            if worst_point < MIN_WALL_DIST:
                best_scale = mid
                low = mid # Fits! Try bigger.
            else:
                high = mid # Too close or Outside! Try smaller.
        except:
            high = mid
            
    return best_scale

# --- WORKER ---
def worker_check_rot(args):
    (rot, search_points, rough_V, rough_F, obstacles_V, obstacles_F, gem_V, gem_F, min_dim, max_dim) = args
    
    # Rebuild meshes
    rough = trimesh.Trimesh(vertices=rough_V, faces=rough_F)
    
    # Convert obstacles to bounds for fast check
    obstacle_bounds = []
    for v, f in zip(obstacles_V, obstacles_F):
        m = trimesh.Trimesh(vertices=v, faces=f)
        obstacle_bounds.append((m.bounds[0] - GEM_SPACING_BUFFER, m.bounds[1] + GEM_SPACING_BUFFER))

    base_gem = trimesh.Trimesh(vertices=gem_V, faces=gem_F)
    base_gem.apply_transform(rot)
    
    best_scale = 0.0
    best_pos = None
    
    for pos in search_points:
        scale = get_max_scale_binary_prox(rough, base_gem, pos, min_dim, max_dim, obstacle_bounds)
        
        if scale > best_scale:
            best_scale = scale
            best_pos = pos
            
    return best_scale, best_pos, rot

def optimize_cut(rough_mesh_path, mode="multi", progress_callback=None):
    print(f"--- Running Geometric Optimization (Proximity Binary Search) ---")
    
    try: rough = trimesh.load(rough_mesh_path)
    except: return []

    # Center to 0
    rough.vertices -= rough.bounds.mean(axis=0)

    # Grid Search
    extents = rough.extents
    min_dim = np.min(extents)
    max_dim = np.max(extents)
    
    offset = np.max(extents) * 0.15
    center = np.array([0.0, 0.0, 0.0])
    search_points = [
        center,
        center + [offset, 0, 0], center - [offset, 0, 0],
        center + [0, offset, 0], center - [0, offset, 0],
        center + [0, 0, offset], center - [0, 0, offset]
    ]

    shapes = get_standard_shapes()
    
    # Rotations
    rotations = [np.eye(4)]
    for axis in [[1,0,0],[0,1,0],[0,0,1]]:
        rotations.append(trimesh.transformations.rotation_matrix(np.pi/2, axis))

    strategies = []
    
    def find_gem(existing_obstacles):
        obs_V = [m.vertices for m in existing_obstacles]
        obs_F = [m.faces for m in existing_obstacles]
        
        tasks = []
        task_info = []
        
        for name, tmpl in shapes.items():
            tmpl_copy = tmpl.copy()
            tmpl_copy.vertices -= tmpl_copy.bounds.mean(axis=0)
            
            gem_V_base = tmpl_copy.vertices
            gem_F_base = tmpl_copy.faces

            for rot in rotations:
                tasks.append((rot, search_points, rough.vertices, rough.faces, obs_V, obs_F, gem_V_base, gem_F_base, min_dim, max_dim))
                task_info.append({"name": name, "gem_template": tmpl_copy})

        total_tasks = len(tasks)
        print(f"   🔥 Launching {total_tasks} Threads...")
        
        global_best = {"vol": 0, "gem": None, "name": ""}
        
        max_cores = os.cpu_count() or 4
        with concurrent.futures.ProcessPoolExecutor(max_workers=max_cores) as executor:
            results = executor.map(worker_check_rot, tasks)
            
            for i, result in enumerate(results):
                if progress_callback and i % 5 == 0:
                     progress_callback(i, total_tasks, "Solving...")
                
                scale, pos, rot = result
                if scale > 0:
                    info = task_info[i]
                    
                    # Apply final safety
                    final_scale = scale * SAFETY_FACTOR
                    
                    # Calculate volume
                    vol = (final_scale**3) * info['gem_template'].volume
                    
                    if vol > global_best["vol"]:
                        global_best["vol"] = vol
                        global_best["name"] = info['name']
                        
                        # Reconstruct Winner
                        win = info['gem_template'].copy()
                        win.apply_transform(rot)
                        win.vertices += pos
                        win.apply_scale(final_scale)
                        global_best["gem"] = win

        return global_best["gem"], global_best["vol"], global_best["name"]

    # STEP 1
    gem1, vol1, name1 = find_gem([])
    
    if not gem1:
        # Safety Fallback
        name1 = list(shapes.keys())[0] + " (Fallback)"
        gem1 = shapes[list(shapes.keys())[0]].copy()
        gem1.apply_scale(min_dim * 0.20)
        gem1.vertices -= gem1.bounds.mean(axis=0)
        vol1 = gem1.volume

    strategies.append({
        "strategy": "Single Large",
        "shape": name1,
        "gems": [gem1],
        "total_volume": vol1
    })

    # STEP 2
    if mode == "multi":
        gem2, vol2, name2 = find_gem([gem1])
        if gem2 and vol2 > (rough.volume * MIN_VOLUME_RATIO):
             strategies.append({
                "strategy": "Multi-Gem",
                "shape": f"{name1} + {name2}",
                "gems": [gem1, gem2],
                "total_volume": vol1 + vol2
            })

    strategies.sort(key=lambda x: x['total_volume'], reverse=True)
    winner = strategies[0]
    
    out = os.path.dirname(rough_mesh_path)
    combined = trimesh.util.concatenate(winner['gems'])
    combined.visual.face_colors = [255, 0, 0, 255]
    combined.export(os.path.join(out, "best_cut.ply"))
    
    return strategies

if __name__ == '__main__':
    pass